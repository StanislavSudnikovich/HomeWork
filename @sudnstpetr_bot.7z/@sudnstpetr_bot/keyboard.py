from aiogram import Bot, types
from aiogram.types import ReplyKeyboardRemove, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, \
    InlineKeyboardButton

start = types.ReplyKeyboardMarkup(resize_keyboard=True)
info = types.KeyboardButton('Информация')
list_lit = types.KeyboardButton('Список полезной литературы')
devel = types.KeyboardButton('Разработчик')


start.add(list_lit, info, devel)
