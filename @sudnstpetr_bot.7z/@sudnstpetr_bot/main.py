import logging
import asyncio
from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardRemove, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, \
    InlineKeyboardButton
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Command
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State

import config
import keyboard

storage = MemoryStorage()

bot = Bot(config.botkey, parse_mode=types.ParseMode.HTML)
# инициализация диспетчера, при этом указываем ему на хранилище состояний
dp = Dispatcher(bot, storage=storage)
# подключаем логирование
logging.basicConfig(
    # указываем название с логами
    filename='log.txt',
    # указываем уровень логирования
    level=logging.INFO,
    # указываем формат сохранения логов
    format=u'%(filename)s [LINE:%(lineno)d] #%(levelname)-8s '
           u'[%(asctime)s] %(message)s')


@dp.message_handler(commands='start', state=None)
async def welcome(message: types.Message):
    joined_file = open('user.txt', 'r')
    joined_users = set()
    for line in joined_file:
        joined_users.add(line.strip())
    if not str(message.chat.id) in joined_users:
        joined_file = open('user.txt', 'a')
        joined_file.write(str(message.chat.id) + '\n')
        joined_users.add(message.chat.id)
    await bot.send_message(
        message.chat.id,
        f'Hello {message.from_user.first_name}',
        # подключаем кнопки из файла keyboard, обратившись к переменной start
        reply_markup=keyboard.start)


# задаем обработчик для нашей кнопки, указываем тип контента как text
@dp.message_handler(content_types=['text'])
# задаем функцию-обработчик
async def info_static(message: types.Message):
    if message.text == 'Информация':
        await bot.send_message(message.chat.id,
                               text='Бот. \nCоздан в образовательных целях',
                               parse_mode='Markdown')
    elif message.text == 'Список полезной литературы':
        await bot.send_message(
            message.chat.id,
            text='Читайте документацию!',
            reply_markup=keyboard.list_lit)
    elif message.text == "Разработчик":
        with open("link.txt", encoding="UTF-8") as link_txt:
            link = link_txt.read()
        with open("text.txt", encoding="UTF-8") as text_txt:
            text = text_txt.read()
        await bot.send_message(message.chat.id, text=f"Разработчик:\n {link} \n {text}")



if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
